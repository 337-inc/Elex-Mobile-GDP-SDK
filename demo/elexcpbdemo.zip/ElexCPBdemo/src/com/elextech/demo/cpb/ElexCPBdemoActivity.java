package com.elextech.demo.cpb;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.elextech.cpb.Cpbelex;
import com.elextech.cpb.Cpbelex.CpbCallback;
import com.elextech.cpb.Cpbelex.CpbExitOKListener;
import com.elextech.cpb.model.ClickArea;
import com.elextech.cpb.model.Reward;

public class ElexCPBdemoActivity extends Activity {
    /** Called when the activity is first created. */
	private String appid = "222";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //CPB初始化
        Cpbelex.init(this, appid, new CpbCallback(){
			@Override
			public void onFinish(Reward arg0) {
				Log.v("GDP DEMO", arg0.getGname());
			}});
        
        Button b = (Button) this.findViewById(R.id.button1);
        b.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0) {
				//弹出CPB推广页面
				Cpbelex.show();
			}});
        
        Button b2 = (Button) this.findViewById(R.id.button2);
        b2.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View arg0) {
				//弹出CPB单页广告
				Cpbelex.setPopadDownArea(new ClickArea(0.25f,0.75f,0.65f,0.75f));
				Cpbelex.setPopadCloseArea(new ClickArea(0.9f,0.99f,0.01f,0.2f));
				Cpbelex.setPopadShowTimes(4);
				Cpbelex.popAd2();
			}});
    }

	@Override
	protected void onResume() {
		
		//每次回到游戏可调用此方法，用于查询是否有需要给与玩家的奖励。会自动调用回调。
		Cpbelex.check();
		super.onResume();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			Cpbelex.popExitAd(new CpbExitOKListener(){
				@Override
				public void okPressed() {
					finish();
				}});
		}
		return true;
	}

    
    
}