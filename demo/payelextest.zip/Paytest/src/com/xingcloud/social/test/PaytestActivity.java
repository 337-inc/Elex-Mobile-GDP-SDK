package com.xingcloud.social.test;

import com.elextech.payment.android.CallbackGame;
import com.elextech.payment.android.Payelex;
import com.elextech.payment.android.PayelexMobileMall;
import com.elextech.payment.model.Order;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.view.View.OnClickListener;

public class PaytestActivity extends Activity {
    /** Called when the activity is first created. */
	String appid = "7ceaeea0d628012ebedd782bcb1b6cfd";
	String uid = "1100";
	boolean isTest=true;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        Button pay = (Button) this.findViewById(R.id.button1);
        pay.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View arg0) {
				Payelex.init(appid, uid, new CallbackGame(){
					@Override
					public boolean onCancelled() {
						return false;
					}

					@Override
					public boolean onFailed(Order arg0) {
						return false;
					}

					@Override
					public boolean onPending(Order arg0) {
						return false;
					}

					@Override
					public boolean onSuccess(Order arg0) {
						return false;
					}}, isTest);
				
				Intent intent = new Intent(PaytestActivity.this,PayelexMobileMall.class);
				intent.putExtra("vamount", 75);	//道具、商品数量
				intent.putExtra("description", "crystals");	//道具、商品描述
				intent.putExtra("gross", "1.99");	//商品总价，交易金额
				intent.putExtra("currency", "USD");	//交易货币标识
				intent.putExtra("productId", "p4");	//产品编号
				startActivity(intent);
			}});
    }
}