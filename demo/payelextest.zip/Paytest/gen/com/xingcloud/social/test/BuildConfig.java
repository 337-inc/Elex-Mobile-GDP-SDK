/** Automatically generated file. DO NOT MODIFY */
package com.xingcloud.social.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}